import os
import json
import asyncio
import random
import time
from playwright.async_api import async_playwright, Browser, BrowserContext, Page
from playwright_stealth import Stealth
from config import COOKIES_PATH, ARENA_TIMEOUT
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────
# URL-маппинг по типу генерации
# ─────────────────────────────────────────────────────────────
ARENA_URLS = {
    "code":  "https://arena.ai/code/direct?model_a=max",
    "text":  "https://arena.ai/text/direct?model_a=max",
    "image": "https://arena.ai/image/direct?model_a=max",
    "video": "https://arena.ai/video",          # всегда 2 варианта
    "prompt": "https://arena.ai/text/direct?model_a=max",  # для генерации промтов
}


class ArenaGenerator:
    def __init__(self):
        self.playwright = None
        self.browser: Browser = None
        self.context: BrowserContext = None
        self.page: Page = None
        self.stealth = Stealth()

    # ─────────────────────────────────────────────────────────
    # Инициализация браузера
    # ─────────────────────────────────────────────────────────
    async def init_browser(self):
        self.playwright = await async_playwright().start()

        self.browser = await self.playwright.chromium.launch(
            headless=True,
            args=[
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-gpu',
                '--disable-blink-features=AutomationControlled',
                '--disable-infobars',
                '--window-size=1920,1080',
            ]
        )

        self.context = await self.browser.new_context(
            viewport={'width': 1920, 'height': 1080},
            user_agent=(
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                'AppleWebKit/537.36 (KHTML, like Gecko) '
                'Chrome/126.0.0.0 Safari/537.36'
            ),
            locale='en-US',
            timezone_id='America/New_York',
            ignore_https_errors=True,
        )

        if os.path.exists(COOKIES_PATH):
            try:
                with open(COOKIES_PATH, 'r', encoding='utf-8') as f:
                    cookies = json.load(f)
                for cookie in cookies:
                    if 'sameSite' not in cookie or cookie['sameSite'] not in ('Strict', 'Lax', 'None'):
                        cookie['sameSite'] = 'Lax'
                await self.context.add_cookies(cookies)
                logger.info(f"Cookies loaded from {COOKIES_PATH}")
            except Exception as e:
                logger.warning(f"Failed to load cookies: {e}")
        else:
            logger.warning(f"Cookies file not found at {COOKIES_PATH}")

        self.page = await self.context.new_page()
        await self.stealth.apply_stealth_async(self.page)

        await self.page.add_init_script("""
            Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
            Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] });
            Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] });
            window.chrome = { runtime: {}, loadTimes: function(){}, csi: function(){}, app: {} };
            const _origQuery = window.navigator.permissions.query;
            window.navigator.permissions.query = (p) =>
                p.name === 'notifications'
                    ? Promise.resolve({ state: Notification.permission })
                    : _origQuery(p);
        """)

        logger.info("Browser initialized with Stealth mode")

    async def close_browser(self):
        if self.browser:
            await self.browser.close()
            logger.info("Browser closed")
        if self.playwright:
            await self.playwright.stop()
            logger.info("Playwright stopped")

    # ─────────────────────────────────────────────────────────
    # Вспомогательные модалки
    # ─────────────────────────────────────────────────────────
    async def accept_cookies(self):
        logger.info("Checking for cookie consent modal...")
        try:
            await self.page.wait_for_selector(
                'button:has-text("Accept Cookies"), button:has-text("Accept"), '
                'button:has-text("Allow"), button:has-text("I agree")',
                timeout=7000
            )
        except Exception:
            logger.info("No cookie consent modal found")
            return False

        for sel in [
            'button:has-text("Accept Cookies")', 'button:has-text("Accept All")',
            'button:has-text("Accept")', 'button:has-text("Allow All")',
            'button:has-text("Allow")', 'button:has-text("I agree")',
            'button:has-text("Got it")', 'button:has-text("OK")',
        ]:
            try:
                el = await self.page.query_selector(sel)
                if el and await el.is_visible():
                    await el.click()
                    logger.info(f"Cookie consent accepted via: {sel}")
                    await asyncio.sleep(2)
                    await self.save_cookies()
                    return True
            except Exception:
                continue

        logger.info("Cookie modal seen but could not be clicked")
        return False

    async def accept_terms(self):
        """Закрываем модалки Terms of Use, Welcome, Announcement, Agree и оверлеи из #root-portal-target"""
        closed_any = False

        # 1. Точечно ищем кнопки закрытия внутри портала модалок #root-portal-target
        portal_close_selectors = [
            '#root-portal-target button:has-text("Agree")',
            '#root-portal-target button:has-text("Accept")',
            '#root-portal-target button:has-text("Close")',
            '#root-portal-target button:has-text("Got it")',
            '#root-portal-target [aria-label*="close" i]',
            '#root-portal-target button',
        ]
        for sel in portal_close_selectors:
            try:
                elements = await self.page.query_selector_all(sel)
                for el in elements:
                    if await el.is_visible():
                        txt = (await el.text_content() or "").strip()
                        # Кликаем если это кнопка согласия/закрытия
                        if any(w in txt.lower() for w in ["agree", "accept", "close", "got it", "continue", "dismiss", "ok"]) or not txt:
                            await el.click()
                            logger.info(f"Closed portal modal via: {sel} ({txt}) ✅")
                            closed_any = True
                            await asyncio.sleep(1)
            except Exception:
                continue

        # Если модалка осталась, пробуем нажать Escape или кликнуть по оверлею
        try:
            await self.page.keyboard.press("Escape")
        except Exception:
            pass

        # 2. Общие селекторы кнопок для закрытия модалок
        close_selectors = [
            'button:has-text("Agree")',
            'button:has-text("I Agree")',
            'button:has-text("Accept")',
            'button:has-text("Close")',
            'button:has-text("Dismiss")',
            'button:has-text("Got it")',
            'button:has-text("Continue")',
            '[aria-label="Close"]',
            '[aria-label="close"]',
            'button[class*="close"]',
        ]
        for sel in close_selectors:
            try:
                elements = await self.page.query_selector_all(sel)
                for el in elements:
                    if await el.is_visible():
                        await el.click()
                        logger.info(f"Closed modal/banner via: {sel} ✅")
                        closed_any = True
                        await asyncio.sleep(1)
            except Exception:
                continue

        # Нажимаем Escape на случай открытого оверлея или дропдауна
        try:
            await self.page.keyboard.press("Escape")
        except Exception:
            pass

        if closed_any:
            await self.save_cookies()
            return True

        logger.info("No Terms/Welcome modal found")
        return False

    async def handle_captcha(self, wait_seconds: int = 5):
        try:
            if wait_seconds > 0:
                try:
                    await self.page.wait_for_selector(
                        'text=/security verification/i', timeout=wait_seconds * 1000
                    )
                except Exception:
                    return False
            else:
                if not await self.page.query_selector('text=/security verification/i'):
                    return False
        except Exception:
            return False

        logger.info("🔒 Security Verification (reCAPTCHA) detected")
        await asyncio.sleep(1.5)

        frame = None
        for _ in range(5):
            for f in self.page.frames:
                if 'recaptcha' in (f.url or ''):
                    frame = f
                    break
            if frame:
                break
            await asyncio.sleep(1)

        try:
            if frame:
                anchor = await frame.wait_for_selector('#recaptcha-anchor', timeout=10000)
                if anchor:
                    box = await anchor.bounding_box()
                    if box:
                        x = box['x'] + box['width'] / 2 + random.uniform(-2, 2)
                        y = box['y'] + box['height'] / 2 + random.uniform(-2, 2)
                        await self.page.mouse.move(x, y, steps=12)
                        await asyncio.sleep(random.uniform(0.3, 0.7))
                        await self.page.mouse.click(x, y, delay=120)
                        logger.info("reCAPTCHA checkbox clicked (human-like) ✅")
                    else:
                        await anchor.click(delay=120)
            else:
                cb = await self.page.query_selector('[role="checkbox"], input[type="checkbox"]')
                if cb:
                    await cb.click(delay=120)
                    logger.info("Captcha checkbox clicked (page-level) ✅")
        except Exception as e:
            logger.warning(f"Captcha click failed: {e}")
            return False

        try:
            await self.page.wait_for_selector(
                'text=/security verification/i', state='detached', timeout=30000
            )
            logger.info("Captcha modal closed ✅")
        except Exception:
            logger.warning("Captcha modal still visible (possibly image challenge)")

        await self.save_cookies()
        return True

    # ─────────────────────────────────────────────────────────
    # Навигация и ожидание UI
    # ─────────────────────────────────────────────────────────
    async def _navigate_and_wait(self, url: str, ui_selector: str = None):
        """Переходим на URL, ждём networkidle, потом ждём UI-элемент."""
        logger.info(f"Navigating to {url}")
        await self.page.goto(url, wait_until="domcontentloaded", timeout=60000)
        try:
            await self.page.wait_for_load_state("networkidle", timeout=20000)
        except Exception:
            pass

        logger.info(f"Current URL: {self.page.url}")

        # Модалки
        await self.accept_cookies()
        await self.accept_terms()
        await self.handle_captcha(wait_seconds=3)

        # Ожидаем UI
        selector = ui_selector or '#chat-area, form textarea, textarea, [role="textbox"]'
        try:
            await self.page.wait_for_selector(selector, timeout=40000)
            logger.info("Main UI rendered ✅")
        except Exception:
            logger.warning("Main UI did not render within 40s — continuing anyway")

        await asyncio.sleep(2)

    # ─────────────────────────────────────────────────────────
    # Ввод и отправка промпта
    # ─────────────────────────────────────────────────────────
    async def enter_prompt(self, prompt: str):
        logger.info(f"Entering prompt: {prompt[:80]}...")

        editor = None
        selectors = [
            'textarea',
            '[contenteditable="true"]',
            '[role="textbox"]',
            'input[type="text"]',
            'form textarea',
            '#chat-area textarea',
            'textarea[placeholder*="message" i]',
            'textarea[placeholder*="prompt" i]',
            'textarea[placeholder*="ask" i]',
            'textarea[placeholder*="describe" i]',
        ]

        # 1. Проверяем селекторы на основной странице
        for sel in selectors:
            try:
                el = await self.page.wait_for_selector(sel, timeout=3000)
                if el and await el.is_visible():
                    editor = el
                    logger.info(f"Prompt editor found: {sel} ✅")
                    break
            except Exception:
                continue

        # 2. Если не найден, проверяем во всех доступных фреймах (iframe)
        if not editor:
            for frame in self.page.frames:
                for sel in selectors:
                    try:
                        el = await frame.query_selector(sel)
                        if el and await el.is_visible():
                            editor = el
                            logger.info(f"Prompt editor found in iframe ({frame.url}): {sel} ✅")
                            break
                    except Exception:
                        continue
                if editor:
                    break

        if not editor:
            # Делаем скриншот для диагностики, если поле не найдено
            try:
                await self.page.screenshot(path="debug_no_input.png")
            except Exception:
                pass
            raise Exception("Could not find prompt input field")

        await editor.click()
        await asyncio.sleep(0.3)
        await self.page.keyboard.press('Control+A')
        await self.page.keyboard.press('Delete')
        await asyncio.sleep(0.3)

        if len(prompt) <= 400:
            await self.page.keyboard.type(prompt, delay=15)
        else:
            await self.page.keyboard.insert_text(prompt)

        await asyncio.sleep(0.5)
        logger.info("Prompt entered ✅")
        return True

    async def submit_prompt(self):
        logger.info("Submitting prompt...")
        
        # Сначала закрываем любые модалки перед отправкой
        await self.accept_terms()
        await self.handle_captcha(wait_seconds=1)

        # Пробуем кликнуть по кнопке отправки (стрелка вверх / вправо или submit)
        clicked_send = False
        send_selectors = [
            'button[type="submit"]',
            'form button:has(svg)',
            'button:has(svg.lucide-arrow-up)',
            'button:has(svg.lucide-arrow-right)',
            'button[aria-label*="send" i]',
            'button[aria-label*="submit" i]',
        ]
        for sel in send_selectors:
            try:
                btns = await self.page.query_selector_all(sel)
                for b in btns:
                    if await b.is_visible() and await b.is_enabled():
                        await b.click()
                        logger.info(f"Clicked send button via: {sel} ✅")
                        clicked_send = True
                        break
                if clicked_send:
                    break
            except Exception:
                continue

        if not clicked_send:
            logger.info("Submitting via Enter...")
            await self.page.keyboard.press('Enter')

        await asyncio.sleep(2)
        await self.accept_terms()
        await self.handle_captcha(wait_seconds=3)
        await asyncio.sleep(2)

        async def started():
            try:
                stop = await self.page.query_selector(
                    'button:has-text("Stop"), button[aria-label*="stop" i]'
                )
                return bool(stop and await stop.is_visible())
            except Exception:
                return False

        if await started():
            logger.info("Generation started ✅")
            return True

        logger.info("Retrying submit (Enter #2)...")
        await self.page.keyboard.press('Enter')
        await asyncio.sleep(2)
        await self.accept_terms()
        await self.handle_captcha(wait_seconds=3)

        if await started():
            logger.info("Generation started ✅")
            return True

        return True

    # ─────────────────────────────────────────────────────────
    # Ожидание кнопки Download (code/landing)
    # ─────────────────────────────────────────────────────────
    async def wait_for_download_button(self, timeout: int):
        logger.info(f"Waiting for active Download button (up to {timeout // 60} min)...")
        start = asyncio.get_event_loop().time()
        last_log = 0

        while (asyncio.get_event_loop().time() - start) < timeout:
            await self.handle_captcha(wait_seconds=0)
            try:
                buttons = await self.page.query_selector_all(
                    'button:has-text("Download"), a:has-text("Download")'
                )
                for b in buttons:
                    if await b.is_visible() and await b.is_enabled():
                        logger.info("Download button is ACTIVE! ✅")
                        return b
            except Exception:
                pass

            elapsed = int(asyncio.get_event_loop().time() - start)
            if elapsed - last_log >= 60:
                logger.info(f"Still generating... {elapsed // 60} min elapsed")
                last_log = elapsed
            await asyncio.sleep(10)

        return None

    async def wait_for_text_done(self, timeout: int = 300) -> str:
        """
        Ждём пока кнопка Stop пропадёт — значит генерация завершена.
        Возвращаем только реальный ответ AI-модели, отсекая меню и шапку Arena.
        """
        logger.info("Waiting for text generation to finish...")
        start = asyncio.get_event_loop().time()

        # Фразы интерфейса Arena, которые нужно игнорировать
        UI_JUNK_PATTERNS = [
            "Follow us for the latest",
            "Experience the frontier",
            "Battle 2 anonymous models",
            "Built for complex tasks",
            "Compare 2 models of your choice",
            "Chat with 1 model at a time",
            "Side by Side",
            "DirectChat",
        ]

        # 1. Ждём, пока начнётся и закончится стриминг/генерация
        await asyncio.sleep(2)
        while (asyncio.get_event_loop().time() - start) < timeout:
            await self.handle_captcha(wait_seconds=0)
            await self.accept_terms()
            try:
                stop = await self.page.query_selector(
                    'button:has-text("Stop"), button[aria-label*="stop" i]'
                )
                if not stop or not await stop.is_visible():
                    break
            except Exception:
                break
            await asyncio.sleep(3)

        await asyncio.sleep(2)

        # 2. Ищем целевой контейнер сообщения ассистента (содержимое чата)
        result = ""
        selectors = [
            '[data-message-author-role="assistant"] .prose',
            '[data-message-author-role="assistant"]',
            'div[class*="assistant"] div[class*="prose"]',
            '.prose',
            '.markdown',
            'article',
        ]
        
        for sel in selectors:
            try:
                els = await self.page.query_selector_all(sel)
                for el in els:
                    if not await el.is_visible():
                        continue
                    t = (await el.text_content() or "").strip()
                    # Проверяем, что это не системный блок с кнопками
                    is_junk = any(junk in t for junk in UI_JUNK_PATTERNS)
                    if t and not is_junk and len(t) > len(result):
                        result = t
            except Exception:
                continue

        # 3. Если всё ещё пусто, фильтруем блоки чата
        if not result:
            try:
                blocks = await self.page.evaluate('''() => {
                    const messages = Array.from(document.querySelectorAll('div, section, p'));
                    return messages
                        .map(m => m.innerText ? m.innerText.trim() : '')
                        .filter(t => t.length > 50);
                }''')
                for b in blocks:
                    if not any(junk in b for junk in UI_JUNK_PATTERNS):
                        if len(b) > len(result):
                            result = b
            except Exception:
                pass

        # 4. Если в результат всё-таки попал ошмёток интерфейса, вычищаем его
        if result:
            for junk in UI_JUNK_PATTERNS:
                if junk in result:
                    lines = [line for line in result.splitlines() if not any(j in line for j in UI_JUNK_PATTERNS)]
                    result = "\n".join(lines).strip()

        logger.info(f"Text generation done, got {len(result)} chars")
        return result

    # ─────────────────────────────────────────────────────────
    # Ожидание картинки (image mode)
    # ─────────────────────────────────────────────────────────
    async def wait_for_image(self, timeout: int = 300, output_dir: str = "generated") -> str:
        """
        Ждём появления сгенерированного изображения и скачиваем/сохраняем его.
        Возвращает путь к файлу.
        """
        logger.info("Waiting for image generation...")
        start = asyncio.get_event_loop().time()
        os.makedirs(output_dir, exist_ok=True)

        while (asyncio.get_event_loop().time() - start) < timeout:
            await self.handle_captcha(wait_seconds=0)
            await self.accept_terms()

            # 1. Проверяем кнопку Download
            try:
                btns = await self.page.query_selector_all(
                    'button:has-text("Download"), a[download], a:has-text("Download"), button[aria-label*="download" i]'
                )
                for b in btns:
                    if await b.is_visible() and await b.is_enabled():
                        logger.info("Image Download button found ✅")
                        ts = int(time.time())
                        filepath = os.path.join(output_dir, f"image_{ts}.png")
                        try:
                            async with self.page.expect_download(timeout=30000) as dl_info:
                                await b.click()
                            dl = await dl_info.value
                            await dl.save_as(filepath)
                            logger.info(f"Image saved to {filepath}")
                            return filepath
                        except Exception as e:
                            logger.warning(f"Download event failed: {e}")
                            break
            except Exception:
                pass

            # 2. Ищем сгенерированное изображение в DOM (исключая аватары и иконки)
            try:
                imgs = await self.page.query_selector_all('img')
                for img in imgs:
                    if not await img.is_visible():
                        continue
                    
                    # Проверяем реальные размеры картинки (отсекаем иконки < 100px)
                    dims = await img.evaluate('el => ({ w: el.naturalWidth || el.clientWidth, h: el.naturalHeight || el.clientHeight, src: el.src })')
                    w = dims.get('w', 0)
                    h = dims.get('h', 0)
                    src = dims.get('src', '')

                    if w > 150 and h > 150:
                        logger.info(f"Generated image detected ({w}x{h}) ✅")
                        ts = int(time.time())
                        filepath = os.path.join(output_dir, f"image_{ts}.png")
                        
                        # Сохраняем скриншотом конкретного элемента (самый надёжный способ без CORS/cookies)
                        await img.screenshot(path=filepath)
                        logger.info(f"Image saved via element screenshot to {filepath} ✅")
                        return filepath
            except Exception as e:
                logger.debug(f"Image DOM check: {e}")

            # 3. Проверяем статус генерации (кнопка Stop)
            try:
                stop = await self.page.query_selector(
                    'button:has-text("Stop"), button[aria-label*="stop" i]'
                )
                if stop and await stop.is_visible():
                    await asyncio.sleep(4)
                    continue
            except Exception:
                pass

            await asyncio.sleep(4)

        raise Exception("Image generation timed out or result not found")

    # ─────────────────────────────────────────────────────────
    # Ожидание видео (video mode — Arena всегда даёт 2 варианта)
    # ─────────────────────────────────────────────────────────
    async def wait_for_video(self, timeout: int = 600, output_dir: str = "generated") -> list[str]:
        """
        Ждёт генерации видео (2 варианта) и скачивает оба.
        Возвращает список путей к видео-файлам.
        """
        logger.info("Waiting for video generation (2 variants)...")
        start = asyncio.get_event_loop().time()
        saved_paths = []

        while (asyncio.get_event_loop().time() - start) < timeout:
            await self.handle_captcha(wait_seconds=0)

            # Кнопки Download
            try:
                btns = await self.page.query_selector_all(
                    'button:has-text("Download"), a[download], a:has-text("Download")'
                )
                active_btns = [b for b in btns if await b.is_visible() and await b.is_enabled()]
                if len(active_btns) >= 2:
                    os.makedirs(output_dir, exist_ok=True)
                    for idx, b in enumerate(active_btns[:2]):
                        ts = int(time.time())
                        filepath = os.path.join(output_dir, f"video_{ts}_{idx}.mp4")
                        try:
                            async with self.page.expect_download(timeout=120000) as dl_info:
                                await b.click()
                            dl = await dl_info.value
                            await dl.save_as(filepath)
                            saved_paths.append(filepath)
                            logger.info(f"Video {idx+1} saved to {filepath}")
                            await asyncio.sleep(2)
                        except Exception as e:
                            logger.warning(f"Video {idx+1} download failed: {e}")
                    if saved_paths:
                        return saved_paths
            except Exception:
                pass

            # Видео в DOM (тег <video>)
            try:
                videos = await self.page.query_selector_all('video')
                visible = [v for v in videos if await v.is_visible()]
                if len(visible) >= 2 and not saved_paths:
                    # Пробуем взять src
                    os.makedirs(output_dir, exist_ok=True)
                    for idx, v in enumerate(visible[:2]):
                        src = await v.get_attribute('src') or ''
                        if src.startswith('http'):
                            saved_paths.append(src)
                    if saved_paths:
                        return saved_paths
            except Exception:
                pass

            await asyncio.sleep(10)

        raise Exception("Video generation timed out or less than 2 results found")

    # ─────────────────────────────────────────────────────────
    # ПУБЛИЧНЫЕ МЕТОДЫ ГЕНЕРАЦИИ
    # ─────────────────────────────────────────────────────────
    async def generate_landing(self, prompt: str, output_dir: str = "generated") -> str:
        """Генерация лендинга (code mode). Возвращает путь к файлу."""
        return await self._generate_code(prompt, output_dir)

    async def generate_code(self, prompt: str, output_dir: str = "generated") -> str:
        """Генерация кода (code mode). Возвращает путь к файлу."""
        return await self._generate_code(prompt, output_dir)

    async def _generate_code(self, prompt: str, output_dir: str = "generated") -> str:
        try:
            if not self.browser:
                await self.init_browser()

            url = ARENA_URLS["code"]
            await self._navigate_and_wait(url)
            await self.page.screenshot(path="debug_01_loaded.png")

            await self.enter_prompt(prompt)
            await self.page.screenshot(path="debug_02_prompt.png")

            await self.submit_prompt()
            await self.page.screenshot(path="debug_03_submitted.png")

            timeout = min(max(int(ARENA_TIMEOUT), 1800), 2400)
            download_button = await self.wait_for_download_button(timeout)

            if not download_button:
                await self.page.screenshot(path="debug_04_no_download.png")
                raise Exception("Download button not found/not active after timeout")

            await self.page.screenshot(path="debug_05_download_ready.png")
            os.makedirs(output_dir, exist_ok=True)

            try:
                async with self.page.expect_download(timeout=120000) as download_info:
                    await download_button.click()
                download = await download_info.value
                ts = int(time.time())
                filename = f"landing_{ts}.zip"
                filepath = os.path.join(output_dir, filename)
                await download.save_as(filepath)
                logger.info(f"✅ Landing saved to {filepath}")
                return filepath

            except Exception as e:
                logger.warning(f"Download event failed, extracting code from DOM: {e}")
                code_blocks = await self.page.query_selector_all('pre code, .cm-content, pre')
                full_code = ""
                for block in code_blocks:
                    text = await block.text_content()
                    full_code += text + "\n"

                if full_code.strip():
                    ts = int(time.time())
                    filepath = os.path.join(output_dir, f"landing_{ts}.html")
                    with open(filepath, "w", encoding="utf-8") as f:
                        f.write(full_code)
                    logger.info(f"✅ Code extracted from DOM and saved to {filepath}")
                    return filepath

                await self.page.screenshot(path="debug_06_extract_failed.png")
                raise Exception("Could not download or extract the landing code.")

        except Exception as e:
            logger.error(f"Error generating code: {e}")
            try:
                await self.page.screenshot(path="debug_error.png")
            except Exception:
                pass
            raise

    async def generate_text(self, prompt: str, timeout: int = 300) -> str:
        """Генерация текста (text mode). Возвращает строку с ответом."""
        try:
            if not self.browser:
                await self.init_browser()

            url = ARENA_URLS["text"]
            await self._navigate_and_wait(url)

            await self.enter_prompt(prompt)
            await self.submit_prompt()

            result = await self.wait_for_text_done(timeout=timeout)
            if not result:
                raise Exception("Empty response from text generation")
            return result

        except Exception as e:
            logger.error(f"Error generating text: {e}")
            try:
                await self.page.screenshot(path="debug_text_error.png")
            except Exception:
                pass
            raise

    async def generate_prompt(self, topic: str, timeout: int = 300) -> str:
        """
        Генерация промта для темы. Отправляем мета-промпт и получаем готовый промпт.
        """
        meta_prompt = (
            f"Write a detailed, creative and professional AI prompt for the following topic: {topic}. "
            f"Output only the prompt text, nothing else."
        )
        return await self.generate_text(meta_prompt, timeout=timeout)

    async def generate_image(self, prompt: str, output_dir: str = "generated", timeout: int = 300) -> str:
        """Генерация картинки (image mode). Возвращает путь к файлу."""
        try:
            if not self.browser:
                await self.init_browser()

            url = ARENA_URLS["image"]
            await self._navigate_and_wait(url)

            await self.enter_prompt(prompt)
            await self.submit_prompt()

            filepath = await self.wait_for_image(timeout=timeout, output_dir=output_dir)
            return filepath

        except Exception as e:
            logger.error(f"Error generating image: {e}")
    async def upload_image(self, image_path: str) -> bool:
        """Загружает исходное изображение для редактирования через input[type=file]"""
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Image file not found: {image_path}")

        logger.info(f"Uploading image for editing: {image_path}...")
        try:
            # Ищем input[type="file"]
            file_input = await self.page.query_selector('input[type="file"]')
            if not file_input:
                # Если input скрыт или привязан к кнопке прикрепления
                attach_btn = await self.page.query_selector('button:has(svg), button[aria-label*="attach" i], button[aria-label*="upload" i]')
                if attach_btn and await attach_btn.is_visible():
                    async with self.page.expect_file_chooser(timeout=5000) as fc_info:
                        await attach_btn.click()
                    file_chooser = await fc_info.value
                    await file_chooser.set_files(image_path)
                    logger.info("Image uploaded via file chooser ✅")
                    await asyncio.sleep(2)
                    return True

            if file_input:
                await file_input.set_input_files(image_path)
                logger.info("Image uploaded via input[type=file] ✅")
                await asyncio.sleep(2)
                return True
        except Exception as e:
            logger.warning(f"File upload interaction error: {e}")

        # Фолбек: делаем input видимым и загружаем
        try:
            await self.page.evaluate('''() => {
                let input = document.querySelector('input[type="file"]');
                if (input) {
                    input.style.display = 'block';
                    input.style.visibility = 'visible';
                }
            }''')
            fi = await self.page.query_selector('input[type="file"]')
            if fi:
                await fi.set_input_files(image_path)
                logger.info("Image uploaded via forced file input ✅")
                await asyncio.sleep(2)
                return True
        except Exception as e:
            logger.error(f"Failed to upload image: {e}")
            raise Exception(f"Failed to attach image for editing: {e}")

        return False

    async def edit_image(self, image_path: str, prompt: str, output_dir: str = "generated", timeout: int = 300) -> str:
        """Редактирование картинки (image edit). Загружает картинку, вводит промпт изменений и возвращает результат."""
        try:
            if not self.browser:
                await self.init_browser()

            url = ARENA_URLS["image"]
            await self._navigate_and_wait(url)

            # 1. Прикрепляем картинку
            await self.upload_image(image_path)

            # 2. Вводим инструкцию для редактирования
            await self.enter_prompt(prompt)

            # 3. Отправляем
            await self.submit_prompt()

            # 4. Ждём результат
            filepath = await self.wait_for_image(timeout=timeout, output_dir=output_dir)
            return filepath

        except Exception as e:
            logger.error(f"Error editing image: {e}")
            try:
                await self.page.screenshot(path="debug_image_edit_error.png")
            except Exception:
                pass
            raise

    async def generate_video(self, prompt: str, output_dir: str = "generated", timeout: int = 600) -> list[str]:
        """
        Генерация видео (video mode — 2 варианта).
        Возвращает список путей к видео-файлам (или URL).
        """
        try:
            if not self.browser:
                await self.init_browser()

            url = ARENA_URLS["video"]
            await self._navigate_and_wait(url, ui_selector='textarea, [role="textbox"]')

            await self.enter_prompt(prompt)
            await self.submit_prompt()

            paths = await self.wait_for_video(timeout=timeout, output_dir=output_dir)
            return paths

        except Exception as e:
            logger.error(f"Error generating video: {e}")
            try:
                await self.page.screenshot(path="debug_video_error.png")
            except Exception:
                pass
            raise

    async def animate_image(self, image_path: str, prompt: str = "", output_dir: str = "generated", timeout: int = 600) -> list[str]:
        """
        Оживление картинки (Image-to-Video).
        Загружает статичную картинку на https://arena.ai/video, задаёт движение/анимацию и возвращает 2 варианта видео.
        """
        try:
            if not self.browser:
                await self.init_browser()

            url = ARENA_URLS["video"]
            await self._navigate_and_wait(url, ui_selector='textarea, [role="textbox"]')

            # 1. Загружаем исходное изображение
            await self.upload_image(image_path)

            # 2. Если промпт не задан, используем стандартную анимацию
            animation_prompt = prompt.strip() if prompt else "Animate this image, natural realistic motion, high quality"
            await self.enter_prompt(animation_prompt)

            # 3. Отправляем
            await self.submit_prompt()

            # 4. Ждём генерации 2 видео
            paths = await self.wait_for_video(timeout=timeout, output_dir=output_dir)
            return paths

        except Exception as e:
            logger.error(f"Error animating image: {e}")
            try:
                await self.page.screenshot(path="debug_animate_error.png")
            except Exception:
                pass
            raise

    # ─────────────────────────────────────────────────────────
    # Cookies
    # ─────────────────────────────────────────────────────────
    async def save_cookies(self):
        if self.context:
            cookies = await self.context.cookies()
            dir_name = os.path.dirname(COOKIES_PATH)
            if dir_name:
                os.makedirs(dir_name, exist_ok=True)
            with open(COOKIES_PATH, 'w', encoding='utf-8') as f:
                json.dump(cookies, f, ensure_ascii=False, indent=2)
            logger.info("Cookies saved")